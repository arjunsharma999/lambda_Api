from fastapi import APIRouter, HTTPException

from pydantic import BaseModel

from mysql.connector import connect, Error

from typing import List, Dict

from io import BytesIO

from fastapi.responses import StreamingResponse

from reportlab.lib.pagesizes import letter, landscape

from reportlab.lib.pagesizes import letter

from reportlab.pdfgen import canvas

import datetime

from reportlab.lib import colors

from .userinfo import UserInfo

from .userinfo import fetch_user_info

import matplotlib.pyplot as plt  

from reportlab.lib.units import inch 

import os  




router = APIRouter()



fetch_user_info()



# Model for specifying the date for the daily report

class ReportDate(BaseModel):

    report_date: str  # Format: 'YYYY-MM-DD'

    

 

# Fetch hourly data including max/min for the specified date

def fetch_hourly_data(report_date: str) -> List[Dict]:

    connection = None

    hourly_data = []

    try:

        connection = connect(

            host='localhost',

            database='weathersensor',

            user='root',

            password='BeagleBone',

            auth_plugin='mysql_native_password'

        )

        if connection.is_connected():

            cursor = connection.cursor(dictionary=True)

            query = """

                SELECT 

                    HOUR(created_at) AS hour,

                    AVG(temperature) AS avg_temperature,

                    AVG(relative_humidity) AS avg_humidity,

                    MAX(temperature) AS max_temperature,

                    MIN(temperature) AS min_temperature,

                    MAX(relative_humidity) AS max_humidity,

                    MIN(relative_humidity) AS min_humidity,

                    AVG(wind_speed) AS avg_wind_speed,

                    AVG(wind_direction) AS avg_wind_direction,

                    AVG(baro_press) AS avg_baro_press,

                    AVG(rain) AS avg_rain,

                    AVG(battery_voltage) AS avg_battery_voltage

                FROM 

                    sensor_data

                WHERE 

                    DATE(created_at) = %s

                GROUP BY 

                    HOUR(created_at)

                ORDER BY 

                    hour;

            """

            cursor.execute(query, (report_date,))

            hourly_data = cursor.fetchall()

            cursor.close()

            print("Hourly data fetched successfully.")

    except Error as e:

        print(f"Error fetching hourly data: {e}")

    finally:

        if connection and connection.is_connected():

            connection.close()

    return hourly_data

    

    # Calculate daily averages and max/min values from hourly data

def calculate_daily_average(hourly_data: List[Dict]) -> Dict:

    daily_avg = {

        "avg_temperature": 0,

        "avg_humidity": 0,

        "max_temperature": float('-inf'),

        "min_temperature": float('inf'),

        "max_humidity": float('-inf'),

        "min_humidity": float('inf'),

        "avg_wind_speed": 0,

        "avg_wind_direction": 0,

        "avg_baro_press": 0,

        "avg_rain": 0,

        "avg_battery_voltage": 0

    }

    count = len(hourly_data)



    for row in hourly_data:

        daily_avg["avg_temperature"] += row["avg_temperature"]

        daily_avg["avg_humidity"] += row["avg_humidity"]

        daily_avg["max_temperature"] = max(daily_avg["max_temperature"], row["max_temperature"])

        daily_avg["min_temperature"] = min(daily_avg["min_temperature"], row["min_temperature"])

        daily_avg["max_humidity"] = max(daily_avg["max_humidity"], row["max_humidity"])

        daily_avg["min_humidity"] = min(daily_avg["min_humidity"], row["min_humidity"])

        daily_avg["avg_wind_speed"] += row.get("avg_wind_speed", 0)

        daily_avg["avg_wind_direction"] += row.get("avg_wind_direction", 0)

        daily_avg["avg_baro_press"] += row.get("avg_baro_press", 0)

        daily_avg["avg_rain"] += row.get("avg_rain", 0)

        daily_avg["avg_battery_voltage"] += row.get("avg_battery_voltage", 0)



       # Finalize average calculations

    if count:

        daily_avg["avg_temperature"] /= count

        daily_avg["avg_humidity"] /= count

        daily_avg["avg_wind_speed"] /= count

        daily_avg["avg_wind_direction"] /= count

        daily_avg["avg_baro_press"] /= count

        daily_avg["avg_rain"] /= count

        daily_avg["avg_battery_voltage"] /= count



    return daily_avg

    

    

    

def create_pdf(hourly_data: List[Dict], daily_avg: Dict, report_date: str, device_info: Dict) -> BytesIO:

    buffer = BytesIO()

    p = canvas.Canvas(buffer, pagesize=landscape(letter))

    width, height = landscape(letter)

    margin_left = 50

    y = height - 50  # Initialize y position for the title



    # Page 1: Tabular Data

    # Draw Device Info

    p.setFont("Helvetica-Bold", 12)

    p.drawString(margin_left, y, f"Device ID: {device_info.get('device_id', 'N/A')}")

    y -= 20

    p.drawString(margin_left, y, f"Location: {device_info.get('location', 'N/A')}")

    y -= 40



    # Title

    p.setFont("Helvetica-Bold", 10)

    p.drawString(margin_left, y, f"Daily Weather Report for {report_date}")

    y -= 40



    # Headers

    headers = [

        "Hour", "Avg Temp", "Avg Hum", 

        "Max Temp", "Min Temp", 

        "Max RH", "Min RH", 

        "Avg Wind S", "Avg Wind D", 

        "Avg Baro P", "Total R", 

        "Avg Battery"

    ]

    units = [

        "", "(C)", "(%)", 

        "(C)", "(C)", 

        "(%)", "(%)", 

        "(km/h)", "()", 

        "(Mbar)", "(mm)", 

        "(V)"

    ]

    column_positions = [50, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720]

    p.setFont("Helvetica-Bold", 8)



    # Header Row

    for i, header in enumerate(headers):

        p.drawString(column_positions[i], y, header)

    y -= 15

    p.setFont("Helvetica", 8)

    for i, unit in enumerate(units):

        p.drawString(column_positions[i], y, unit)

    y -= 5

    p.line(margin_left, y, width - margin_left, y)  # Underline headers

    

     # Tabular Data Rows

    p.setFont("Helvetica", 7)

    for row in hourly_data:

        y -= 15

        if y < 50:  # Add a new page if space runs out

            p.showPage()

            y = height - 50

        p.drawString(column_positions[0], y, f"{row['hour']}:00")

        p.drawString(column_positions[1], y, f"{row['avg_temperature']:.2f}")

        p.drawString(column_positions[2], y, f"{row['avg_humidity']:.2f}")

        p.drawString(column_positions[3], y, f"{row['max_temperature']:.2f}")

        p.drawString(column_positions[4], y, f"{row['min_temperature']:.2f}")

        p.drawString(column_positions[5], y, f"{row['max_humidity']:.2f}")

        p.drawString(column_positions[6], y, f"{row['min_humidity']:.2f}")

        p.drawString(column_positions[7], y, f"{row['avg_wind_speed']:.2f}")

        p.drawString(column_positions[8], y, f"{row['avg_wind_direction']:.2f}")

        p.drawString(column_positions[9], y, f"{row['avg_baro_press']:.2f}")

        p.drawString(column_positions[10], y, f"{row['avg_rain']:.2f}")

        p.drawString(column_positions[11], y, f"{row['avg_battery_voltage']:.2f}")

        

    y -= 10

    p.line(margin_left, y, width - margin_left, y)



    # Daily Average Row

    y -= 15

    p.setFont("Helvetica-Bold", 8)

    p.drawString(column_positions[0], y, "Daily Average")

    p.setFont("Helvetica", 7)

    p.drawString(column_positions[1], y, f"{daily_avg['avg_temperature']:.2f}")

    p.drawString(column_positions[2], y, f"{daily_avg['avg_humidity']:.2f}")

    p.drawString(column_positions[3], y, f"{daily_avg['max_temperature']:.2f}")

    p.drawString(column_positions[4], y, f"{daily_avg['min_temperature']:.2f}")

    p.drawString(column_positions[5], y, f"{daily_avg['max_humidity']:.2f}")

    p.drawString(column_positions[6], y, f"{daily_avg['min_humidity']:.2f}")

    p.drawString(column_positions[7], y, f"{daily_avg['avg_wind_speed']:.2f}")

    p.drawString(column_positions[8], y, f"{daily_avg['avg_wind_direction']:.2f}")

    p.drawString(column_positions[9], y, f"{daily_avg['avg_baro_press']:.2f}")

    p.drawString(column_positions[10], y, f"{daily_avg['avg_rain']:.2f}")

    p.drawString(column_positions[11], y, f"{daily_avg['avg_battery_voltage']:.2f}")



    p.showPage()  # End of Page 1

    

     # Page 2: Graphs

     

        # Title

        

    graphs = []    

    p.setFont("Helvetica-Bold", 10)

    p.setFillColor(colors.red) 

    p.drawString(margin_left, y, f"Visual Rpresentation of Data {report_date}")

    

    

    for parameter in ["temperature", "humidity", "wind_speed", "wind_direction", "baro_press", "rain", "battery_voltage"]:

        fig, ax = plt.subplots()

        ax.plot([row[f"avg_{parameter}"] for row in hourly_data])

        ax.set_title(f"Average {parameter.capitalize()}")

        ax.set_xlabel("Hour")

        ax.set_ylabel(parameter.capitalize())

        filename = f"{parameter}.png"

        fig.savefig(filename)

        graphs.append(filename)

        plt.close(fig)



    for i, graph in enumerate(graphs):

        if i % 4 == 0 and i != 0:

            p.showPage()



        # 2x2 grid layout

        x_position = margin_left + (i % 2) * (width / 2)

        y_position = height - 200 - (i // 2 % 2) * 200

        p.drawImage(graph, x_position, y_position, width=300, height=150)



    p.save()

    buffer.seek(0)

    return buffer

   

    

@router.post("/generate/daily/report")

async def generate_report(report_date: ReportDate):

    # Fetch device information

    device_info = fetch_user_info()



    # Check if device info was retrieved

    if not device_info:

        raise HTTPException(status_code=404, detail="Device information not found.")

    

    # Fetch hourly data

    hourly_data = fetch_hourly_data(report_date.report_date)

    

    if not hourly_data:

        raise HTTPException(status_code=404, detail="No data found for the specified date.")

    

    # Calculate daily average

    daily_avg = calculate_daily_average(hourly_data)

    

    # Create PDF report

    pdf_data = create_pdf(hourly_data, daily_avg, report_date.report_date, device_info)

    

    # Return the PDF as a streaming response

    response = StreamingResponse(pdf_data, media_type="application/pdf")

    response.headers["Content-Disposition"] = f"attachment; filename=daily_report_{report_date.report_date}.pdf"

    

    return response    

