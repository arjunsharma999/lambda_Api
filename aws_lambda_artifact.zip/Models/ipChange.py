import os
import threading
import time
import serial
import re
import subprocess
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

# NetworkConfigurator Class
class NetworkConfigurator:
    def __init__(self, interface, dhcpcd_conf="/etc/dhcpcd.conf"):
        self.interface = interface
        self.dhcpcd_conf = dhcpcd_conf
        self.backup_conf = dhcpcd_conf + ".backup"
        self.backup_config()
        
        
    def backup_config(self):
        try:
            if os.path.exists(self.dhcpcd_conf):
                os.system(f"sudo cp {self.dhcpcd_conf} {self.backup_conf}")
            else:
                print(f"Configuration file {self.dhcpcd_conf} not found.")
        except Exception as e:
            print(f"Failed to create backup: {str(e)}")
            
            
    def read_config(self):
        try:
            with open(self.dhcpcd_conf, "r") as file:
                return file.readlines()
        except FileNotFoundError:
            print(f"{self.dhcpcd_conf} not found.")
            return None
        except Exception as e:
            print(f"Error reading {self.dhcpcd_conf}: {str(e)}")
            return None    
            
    def write_config(self, lines):
        temp_file = "/tmp/dhcpcd_conf.temp"
        try:
            with open(temp_file, "w") as file:
                file.writelines(lines)
            os.system(f"sudo mv {temp_file} {self.dhcpcd_conf}")
        except Exception as e:
            print(f"Error writing configuration: {str(e)}")

    def validate_ip(self, ip):
        ip_regex = re.compile(
            r'^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.' 
            r'(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.' 
            r'(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.' 
            r'(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        )
        if not ip_regex.match(ip):
            print(f"Invalid IP address format: {ip}")
            return False
        return True    
			
			
    def change_ip_address(self, new_ip, routers, dns_servers):
        if not self.validate_ip(new_ip):
            return {"status": "error", "message": f"Invalid IP address: {new_ip}"}
        if not self.validate_ip(routers):
            return {"status": "error", "message": f"Invalid router address: {routers}"}

        lines = self.read_config()
        if lines is None:
            return {"status": "error", "message": "Failed to read the network configuration file."}

        new_conf = []
        inside_static_block = False

        for line in lines:
            if line.startswith(f"interface {self.interface}"):
                inside_static_block = True

            if inside_static_block and line.strip().startswith("static ip_address"):
                new_conf.append(f"static ip_address={new_ip}/24\n")
            elif inside_static_block and line.strip().startswith("static routers"):
                new_conf.append(f"static routers={routers}\n")
            elif inside_static_block and line.strip().startswith("static domain_name_servers"):
                new_conf.append(f"static domain_name_servers={dns_servers}\n")
            elif inside_static_block and line.strip() == "":
                inside_static_block = False
                new_conf.append(line)
            else:
                new_conf.append(line)
                
        if not inside_static_block:
            new_conf.append(f"\ninterface {self.interface}\n")
            new_conf.append(f"static ip_address={new_ip}/24\n")
            new_conf.append(f"static routers={routers}\n")
            new_conf.append(f"static domain_name_servers={dns_servers}\n")

        # Write the new configuration
        self.write_config(new_conf)

        if self.restart_dhcpcd():
            if self.restart_pi():
                return {"status": "success", "message": f"IP address changed to {new_ip} successfully."}
            else:
                return {"status": "error", "message": "Failed to restart the Raspberry Pi after changing IP address."}
        else:
            return {"status": "error", "message": "Failed to restart the DHCP service."}
            
            
    def restart_dhcpcd(self):
        try:
            subprocess.run(["sudo", "systemctl", "restart", "dhcpcd"], check=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error restarting dhcpcd: {str(e)}")
            return False

    def restart_pi(self):
        try:
            subprocess.run(["sudo", "reboot"], check=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error rebooting system: {str(e)}")
            return False
 
# IPSending Class
class IPSending:
    def __init__(self, serial_port, baud_rate, interface):
        self.serial_port = serial_port
        self.baud_rate = baud_rate
        self.interface = interface
        self.configurator = NetworkConfigurator(interface)
        self.running = False
        self.lock = threading.Lock()
        self.ip_thread = None

    def format_ip(self, ip_address):
        octets = ip_address.split('.')
        padded_octets = [octet.zfill(3) for octet in octets]
        return "IP," + ".".join(padded_octets) + ";\r\n"
        
        
    def send_ip_to_sensor(self):
        while self.running:
            try:
                current_ip = os.popen('hostname -I').read().strip()
                ip_list = current_ip.split()
                last_ip = ip_list[-1]
                formatted_ip = self.format_ip(last_ip)

                with self.lock:
                    with serial.Serial(self.serial_port, self.baud_rate, timeout=1) as ser:
                        ser.write(formatted_ip.encode())
                time.sleep(30)
            except serial.SerialException as e:
                print(f"Serial port error: {e}")
                time.sleep(1)
            except Exception as e:
                print(f"Error sending IP to sensor: {e}")       
                
    def start_sending_ip(self):
        if not self.running:
            self.running = True
            self.ip_thread = threading.Thread(target=self.send_ip_to_sensor)
            self.ip_thread.daemon = True
            self.ip_thread.start()

    def stop_sending_ip(self):
        self.running = False
        if self.ip_thread is not None:
            self.ip_thread.join()                              
        

    # Define the request model
class IPChangeRequest(BaseModel):
    new_ip: str
    routers: str
    dns_servers: str

# Initialize NetworkConfigurator
network_configurator = NetworkConfigurator(interface="eth0")  # Replace with your actual interface

@app.post("/change/ip/")
async def change_ip(request: IPChangeRequest):
    """
    Endpoint to change the IP address, router, and DNS server configuration.
    """
    try:
        response = network_configurator.change_ip_address(
            new_ip=request.new_ip,
            routers=request.routers,
            dns_servers=request.dns_servers
        )
        if response["status"] == "success":
            return {"message": response["message"]}
        else:
            raise HTTPException(status_code=400, detail=response["message"])
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
