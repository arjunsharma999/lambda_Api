from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from mysql.connector import connect, Error
from typing import Dict, Optional

router = APIRouter()

class UserInfo(BaseModel):
    device_id: str
    location: str

def fetch_user_info(device_id: Optional[str] = None) -> Dict:
    """
    Fetch user information by device_id.
    If device_id is not provided, fetch the most recently updated record.
    """
    connection = None
    device_info = {}
    try:
        connection = connect(
            host='localhost',
            database='weathersensor',
            user='root',
            password='BeagleBone',
            auth_plugin='mysql_native_password'
        )
        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)
            if device_id:
                query = "SELECT device_id, location FROM user_info WHERE device_id = %s;"
                cursor.execute(query, (device_id,))
            else:
                query = "SELECT device_id, location FROM user_info ORDER BY updated_at DESC LIMIT 1;"
                cursor.execute(query)
            
            device_info = cursor.fetchone()
            cursor.close()
            print("Device information fetched successfully.")
    except Error as e:
        print(f"Error fetching device information: {e}")
    finally:
        if connection and connection.is_connected():
            connection.close()
    return device_info

@router.post("/user/info")
async def save_user_info(user_info: UserInfo):
    connection = None
    try:
        connection = connect(
            host='localhost',
            database='weathersensor',
            user='root',
            password='BeagleBone',
            auth_plugin='mysql_native_password'
        )
        
        if connection.is_connected():
            cursor = connection.cursor()
            
            # Check if the device_id already exists
            cursor.execute("SELECT COUNT(*) FROM user_info WHERE device_id = %s", (user_info.device_id,))
            count = cursor.fetchone()[0]

            if count > 0:
                # Update existing user info
                query = """
                    UPDATE user_info
                    SET location = %s, updated_at = NOW()
                    WHERE device_id = %s
                """
                cursor.execute(query, (user_info.location, user_info.device_id))
                connection.commit()
                cursor.close()
                return {"message": "User info updated successfully!"}
            else:
                # Insert new user info
                query = """
                    INSERT INTO user_info (device_id, location, updated_at)
                    VALUES (%s, %s, NOW())
                """
                cursor.execute(query, (user_info.device_id, user_info.location))
                connection.commit()
                cursor.close()
                return {"message": "User info saved successfully!"}
    
    except Error as e:
        print(f"Error saving user info: {e}")
        raise HTTPException(status_code=500, detail="Error saving user info")

    finally:
        if connection and connection.is_connected():
            connection.close()
