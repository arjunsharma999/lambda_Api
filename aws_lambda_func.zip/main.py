import logging
import os
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from Routes.routes import sensor_router
from Models.sensor import data_fetcher
from Models.download_data import router as download_router
from Models.reports import router as report_router
from Models.userinfo import router as user_info_router 
from contextlib import asynccontextmanager
from mangum import Mangum
from Models.ipChange import app as ipchange_app


# Set up centralized logging
log_directory = "logs"
os.makedirs(log_directory, exist_ok=True)  
log_file = os.path.join(log_directory, "application.log")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(log_file),   
        logging.StreamHandler()         
    ]
)

app = FastAPI()
handler = Mangum(app)

app.mount("/ipchange", ipchange_app)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routes
app.include_router(sensor_router)
app.include_router(download_router)  
app.include_router(report_router)
app.include_router(user_info_router) 


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        logging.info("Starting data fetcher")
        data_fetcher.start_fetching()  
        yield
    except Exception as e:
        logging.error("Error during lifespan startup: %s", e)
    finally:
        logging.info("Shutting down data fetcher")
        data_fetcher.stop_fetching() 

app.router.lifespan_context = lifespan

if __name__ == "__main__":
    logging.info("Starting the FastAPI application")
    try:
        uvicorn.run(app, host="0.0.0.0", port=8000)
    except Exception as e:
        logging.error("Failed to start the server: %s", e)
    finally:
        logging.info("Server shutdown")
