# fetch_data.py

from fastapi import FastAPI, HTTPException, APIRouter
from pydantic import BaseModel
import mysql.connector
from mysql.connector import Error
from typing import List, Dict
import csv
from io import StringIO
from fastapi.responses import StreamingResponse

router = APIRouter()

# Define a model for the query parameters, now with separate date and time fields
class DateRange(BaseModel):
    start_date: str  # Format: 'YYYY-MM-DD'
    start_time: str  # Format: 'HH:MM:SS'
    end_date: str    # Format: 'YYYY-MM-DD'
    end_time: str    # Format: 'HH:MM:SS'

# Custom headers (column names) you want in your CSV, including max and min values
custom_headers = [
    "Date", "Time", "Temperature (degC) ", "Max Temperature (degC)", "Min Temperature (degC)", 
    "Humidity (%)", "Max Humidity (%)", "Min Humidity (%)", "Wind Speed (km/h)", 
    "Max Wind Speed (km/h)", "Wind Direction", "Barometric Pressure (hPa)", 
    "Rainfall (mm)", "Battery Voltage (V)"
]

# Specify the order/sequence in which the data should appear based on your custom headers
sequence = [
    "date", "time", "temperature", "max_temperature", "min_temperature", 
    "relative_humidity", "max_rh", "min_rh", "wind_speed", "max_wind_speed", 
    "wind_direction", "baro_press", "rain", "battery_voltage"
]

# Function to fetch data from the database based on the date and time range
def fetch_data_from_db(start_date: str, start_time: str, end_date: str, end_time: str) -> List[Dict]:
    connection = None
    results = []
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='weathersensor',
            user='root',
            password='BeagleBone',
            auth_plugin='mysql_native_password'
        )
        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)
            # Combine date and time into a single datetime format for the query
            start_datetime = f"{start_date} {start_time}"
            end_datetime = f"{end_date} {end_time}"

            query = """
                SELECT * FROM sensor_data 
                WHERE created_at BETWEEN %s AND %s
                ORDER BY created_at ASC
            """
            cursor.execute(query, (start_datetime, end_datetime))
            results = cursor.fetchall()
            cursor.close()
            print("Data fetched successfully.")
    except Error as e:
        print(f"Error fetching data: {e}")
    finally:
        if connection and connection.is_connected():
            connection.close()
    return results

# Helper function to convert data to CSV with custom headers and sequence
def data_to_csv(data: List[Dict]) -> StringIO:
    # Create a string buffer to write the CSV data
    csv_file = StringIO()

    # Create a CSV writer with custom headers
    writer = csv.DictWriter(csv_file, fieldnames=custom_headers)
    
    # Write the custom header
    writer.writeheader()
    
    # Write the rows in the sequence of the custom headers
    for row in data:
        # Create a new ordered dictionary based on the sequence
        ordered_row = {custom_headers[i]: row.get(sequence[i], None) for i in range(len(sequence))}
        writer.writerow(ordered_row)
    
    # Move the cursor of the file back to the start
    csv_file.seek(0)
    
    return csv_file

# API endpoint to retrieve data and serve as a CSV
@router.post("/fetch_data", response_model=List[Dict])
async def get_data(date_range: DateRange):
    data = fetch_data_from_db(
        date_range.start_date,
        date_range.start_time,
        date_range.end_date,
        date_range.end_time
    )
    
    if not data:
        raise HTTPException(status_code=404, detail="No data found for the given date and time range.")
    
    # Convert data to CSV
    csv_data = data_to_csv(data)
    
    # Return the CSV as a streaming response
    response = StreamingResponse(csv_data, media_type="text/csv")
    response.headers["Content-Disposition"] = "attachment; filename=sensor_data.csv"
    
    return response
