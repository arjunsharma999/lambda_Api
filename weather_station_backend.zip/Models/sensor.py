import serial
import time
from datetime import datetime, timedelta
import mysql.connector
from mysql.connector import Error
from threading import Thread
from pydantic import BaseModel
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from twilio.rest import Client
import requests
import json
import logging 
from dotenv import load_dotenv
import os
from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient 
from Models.userinfo import fetch_user_info

load_dotenv()

#Initilaize Email credentials
alert_email = os.getenv('ALERT_EMAIL')
alert_password = os.getenv('ALERT_PASSWORD')
recipient_email = os.getenv('RECIPIENT_EMAIL')

# Initialize MQTT Credentials
mqtt_host = os.getenv('MQTT_HOST')
mqtt_port = int (os.getenv('MQTT_PORT'))
mqtt_cert_path = os.getenv('MQTT_CERT_PATH')
mqtt_key_path = os.getenv('MQTT_KEY_PATH')
mqtt_ca_path = os.getenv('MQTT_CA_PATH')

# Initialize the DB
db_host = os.getenv('DB_HOST')
db_name = os.getenv('DB_NAME')
db_user = os.getenv('DB_USER')
db_password = os.getenv('DB_PASSWORD')

# Initialize the MQTT client  
mqtt_client = AWSIoTMQTTClient("SensorDataFetcher")  
mqtt_client.configureEndpoint(mqtt_host, mqtt_port)  
mqtt_client.configureCredentials(mqtt_ca_path, mqtt_key_path, mqtt_cert_path)  
mqtt_client.configureOfflinePublishQueueing(-1)  
mqtt_client.configureDrainingFrequency(2)  
mqtt_client.configureConnectDisconnectTimeout(10)  
mqtt_client.configureMQTTOperationTimeout(5)  
mqtt_client.connect()  
TOPIC = "sensor/data" 

# fetch sensor data
class SensorDataFetcher:
    def __init__(self, port_address, baud_rate, timeout=0.1, logging_interval=30):
        self.port_address = port_address
        self.baud_rate = baud_rate
        self.timeout = timeout
        self.logging_interval = logging_interval  # in seconds
        self.is_running = False
        self.parameters = None
        self.last_data = None
        self.last_logged_time = datetime.now()
        self.reset_rain = False
        self.alert_email = "arjun.sharma@sensormart.co.in"  # Replace with your email
        self.alert_password = "npgx vcer golz uisj"  # Replace with your app password
        self.recipient_email = "arjunsharmarke99@gmail.com"
        self.recipient_phone = ""

        # Initialize max/min values and thresholds
        self.max_temperature = float('-inf')
        self.min_temperature = float('inf')
        self.max_rh = float('-inf')
        self.min_rh = float('inf')
        self.max_wind_speed = float('-inf')
        self.min_wind_speed = float('inf')
        self.max_wind_direction = float('-inf')
        self.min_wind_direction = float('inf')
        self.max_rain = float('-inf')
        self.min_rain = float('inf')
        self.max_baro_press = float('-inf')
        self.min_baro_press = float('inf')
        self.max_battery_voltage =  float('-inf')
        self.min_battery_voltage =  float('inf')
        self.device_id = ""
        
        self.thresholds = {
            "temperature": {"min": 0, "max": 90}, 
            "relative_humidity": {"min": 20, "max": 300},
            "wind_speed": {"min": 0, "max": 0},
            "wind_direction": {"min": 0 , "max": 0},
            "rain": {"min": 0, "max": 0 },
            "battery_voltage": {"min": 0, "max": 20},
            "baro_press": {"min": 0, "max": 1000}
        }
        
        self.alert_sent = {}
        self.alert_count = 0

    def send_whatsapp_message (self, data, device_id, location, recipient_phone=None):
        if recipient_phone is None:
            recipient_phone = self.recipient_phone

        api_url = "http://bhashsms.com/api/sendmsg.php"
        params = {
            'user': 'kbrothers',
            'pass': 'prasanna@1105',
            'sender': 'BUZWAP',
            'phone': recipient_phone,
            'text': 'kb_final',
            'priority': 'wa',
            'stype': 'normal',
            "params": f"{device_id},{location},{data['date_time']},{data['temperature']},{data['relative_humidity']},{data['wind_speed']},{data['wind_direction']},{data['rain']},{data['baro_press']},{data['battery_voltage']}"
        }

        try:
            # Sending GET request
            response = requests.get(api_url, params=params)
            
            # Check if the request was successful
            if response.status_code == 200:
                print("Message sent successfully!")
                print("Response:", response.text)
            else:
                print(f"Failed to send message. Status code: {response.status_code}")
                print("Response:", response.text)
        except requests.exceptions.RequestException as e:
            print(f"An error occurred: {e}")

    # Function to send email in a separate thread
    def send_email_in_thread(self, subject, device_id, location, message):
        """Run the email sending logic in a separate thread."""
        try:
            print("Preparing to send email alert...")
            
            
            if device_id or location:
                dynamic_content = f"\nDevice ID: {device_id}\nLocation: {location}\n" 
                message += dynamic_content
            
            # Set up email
            msg = MIMEMultipart()
            msg['From'] = self.alert_email
            msg['To'] = self.recipient_email
            msg['Subject'] = subject

            # Add body
            msg.attach(MIMEText(message, 'plain'))

            # Set up server
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(self.alert_email, self.alert_password)
            server.send_message(msg)
            server.quit()
            print("Email alert sent successfully.")
        except Exception as e:
            print(f"Failed to send email alert: {e}")


    def fetch_parameters(self):
        """Fetch available sensor parameters from the device."""
        try:
            print("Attempting to fetch sensor parameters...")
            with serial.Serial(self.port_address, self.baud_rate, timeout=self.timeout) as ser:
                ser.write(b'?')
                params_data = ser.readline().decode('utf-8').strip()
                self.parameters = params_data if params_data else None
               # print(f"Fetched parameters: {self.parameters}")
        except Exception as e:
            print(f"Error fetching parameters: {e}")

    def fetch_data(self):
        print("Starting data fetching...")
        while self.is_running:
            try:
                with serial.Serial(self.port_address, self.baud_rate, timeout=self.timeout) as ser:
                    ser.write(b'!')
                    values_data = ser.readline().decode('utf-8').strip().rstrip(';')
                    self.last_data = values_data if values_data else None
                   # print(f"Fetched data: {values_data}")
                    
                    if self.last_data:
                        data_dict = self.parse_sensor_data(self.last_data)
                        
                        data_dict['timestamp'] = datetime.now().isoformat()
                        
                        if data_dict["rain"] > 0:
                            self.reset_rain = True
                        self.update_min_max(self.last_data)
                        self.store_data_if_interval_passed()
                        self.publish_to_mqtt(TOPIC, json.dumps(data_dict))
            except Exception as e:
                print(f"Error fetching data: {e}")
            finally:
                time.sleep(1)
                
        # Publishing to MQTT            
    def publish_to_mqtt(self, topic, message):
        """Publish sensor data to the specified MQTT topic."""
        mqtt_client.publish(topic, message, 1)  # Publish the message with QoS=1
        logging.info("Published data to MQTT topic: %s", TOPIC)
        print(f"Published data to MQTT topic {topic}: {message}")   
        

    def parse_sensor_data(self, data_row):
        """Parse a row of sensor data and return it as a dictionary."""
       # print(f"Parsing data row: {data_row}")
        values = data_row.split(",")
        return {
            "temperature": float(values[0]),
            "relative_humidity": float(values[1]),
            "wind_speed": float(values[2]),
            "wind_direction": float(values[3]),
            "baro_press": float(values[4]),
            "rain": float(values[5]),
            "battery_voltage": float(values[6]),
        }

    def update_min_max(self, data_row):
        """Update min/max values and send alerts if thresholds are breached."""
        data = self.parse_sensor_data(data_row)
       # print(f"Updating min/max values with data: {data}")
    
        self.max_temperature = max(self.max_temperature, data["temperature"])
        self.min_temperature = min(self.min_temperature, data["temperature"])
        self.max_rh = max(self.max_rh, data["relative_humidity"])
        self.min_rh = min(self.min_rh, data["relative_humidity"])
        self.max_wind_speed = max(self.max_wind_speed, data["wind_speed"])
        self.min_wind_speed = min(self.min_wind_speed, data["wind_speed"])
        self.max_wind_direction = max(self.max_wind_direction, data["wind_direction"])
        self.min_wind_direction = min(self.min_wind_direction, data["wind_direction"])
        self.max_rain = max(self.max_rain, data["rain"])
        self.min_rain = min(self.min_rain, data["rain"])
        self.max_baro_press = max(self.max_baro_press, data["baro_press"])
        self.min_baro_press = min(self.min_baro_press, data["baro_press"]) 
        self.max_battery_voltage = max(self.max_battery_voltage, data["battery_voltage"])
        self.min_battery_voltage = min(self.min_battery_voltage, data["battery_voltage"])
        
        alert_triggered = False
        alert_message = "Range Alarm\n\n"
        alert_params = {}
        
        for param, limits in self.thresholds.items():
            value = data[param]
            if value < limits["min"] or value > limits["max"]:
                if not self.alert_sent.get(param, False):
                    alert_triggered = True
                    alert_message += f"{param} is out of range! Current value: {value} (Allowed: {limits['min']} - {limits['max']})\n"
                    alert_params[param] = value
                    self.alert_sent[param] = True

        # Send alert if triggered
        if alert_triggered: 
            #self.alert_count += len(alert_params)
            print(f"alert has come: {self.alert_count}")
            print("Threshold breached. Triggering alert...")  
            
            device_data = fetch_user_info()  
            device_id = device_data["device_id"]  
            location = device_data["location"]
            
            Thread(target=self.send_email_in_thread, args=("Sensor Alert",device_id, location, alert_message)).start()  
                
            data = {  
                'date_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),  
                'temperature': self.max_temperature,  
                'relative_humidity': self.max_rh,  
                'wind_speed': self.max_wind_speed, 
                'wind_direction':self.max_wind_direction,
                'baro_press': self.max_baro_press,  
                'rain': self.max_rain,  
                'battery_voltage': self.max_battery_voltage  
            }  
                
            Thread(target=self.send_whatsapp_message, args=(data, device_id, location)).start()
            
        for param, limits in self.thresholds.items():  
          value = data[param]  
          if limits["min"] <= value <= limits["max"] and self.alert_sent.get(param, False):  
            self.alert_sent[param] = False  # Reset alert sent flag for this parameter   
            
    '''def reset_alert_flag(self):
        """Reset the general alert flag."""
        self.alert_sent = False 
        '''  
            
    def store_data_if_interval_passed(self):
        """Check if the logging interval has passed and store the data if it has."""
        current_time = datetime.now()
        if (current_time - self.last_logged_time).total_seconds() >= self.logging_interval:
          #  print("Logging data now...")
            self.store_data(self.last_data)
            self.last_logged_time += timedelta(seconds=self.logging_interval)  # Update based on interval
            self.reset_min_max()

            if self.reset_rain:
                self.reset_rain_data()
                self.reset_rain = False

    def reset_rain_data(self):
        try:
            with serial.Serial(self.port_address, self.baud_rate, timeout=self.timeout) as ser:
                ser.write(b'R')
                print('Rain data reset successfully.')
        except Exception as e:
            print(f'Error resetting rain data: {e}')

    def reset_min_max(self):
        """Reset min/max values for the next logging interval."""
        print("Resetting min/max values for the next interval.")
        self.max_temperature = float('-inf')
        self.min_temperature = float('inf')
        self.max_rh = float('-inf')
        self.min_rh = float('inf')
        self.max_wind_speed = float('-inf')
        self.min_wind_speed = float('inf')
        self.max_wind_direction = float('-inf')
        self.min_wind_direction = float('inf')
        self.max_rain = float('-inf')
        self.min_rain = float('inf')
        self.max_baro_press = float('-inf')
        self.min_baro_press = float('inf')
        self.max_battery_voltage =  float('-inf')
        self.min_battery_voltage =  float('inf')
          
    def store_data(self, data_row):
        """Store the fetched sensor data in the MariaDB database."""
        print("Storing data in the database...")
        connection = None
        try:
            parsed_data = self.parse_sensor_data(data_row)
           # print(f"Parsed Data: {parsed_data}")
            connection = mysql.connector.connect(
                host=db_host,
                database=db_name,
                user=db_user,
                password=db_password,
                auth_plugin='mysql_native_password'
            )

            if connection.is_connected():
                cursor = connection.cursor()
                date, time_value = datetime.now().strftime('%Y-%m-%d'), datetime.now().strftime('%H:%M:%S')
                insert_query = """
                INSERT INTO sensor_data 
                (data_row, date, time, temperature, relative_humidity, wind_speed, wind_direction, baro_press, rain, battery_voltage, 
                 max_temperature, min_temperature, max_rh, min_rh, max_wind_speed)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
              #  print(f"Executing query with values: {data_row, date, time_value, parsed_data['temperature'], parsed_data['relative_humidity'], parsed_data['wind_speed'], parsed_data['wind_direction'], parsed_data['baro_press'], parsed_data['rain'], parsed_data['battery_voltage'], self.max_temperature, self.min_temperature, self.max_rh, self.min_rh, self.max_wind_speed}")
                cursor.execute(insert_query, (
                    data_row, date, time_value,
                    parsed_data["temperature"], parsed_data["relative_humidity"],
                    parsed_data["wind_speed"], parsed_data["wind_direction"],
                    parsed_data["baro_press"], parsed_data["rain"], parsed_data["battery_voltage"],
                    self.max_temperature, self.min_temperature, self.max_rh, self.min_rh, self.max_wind_speed
                ))
                connection.commit()
                print("Data successfully inserted into the database.")
                cursor.close()

        except Error as e:
            print(f"Error storing data: {e}")

        finally:
            if connection and connection.is_connected():
                connection.close()


    def start_logging_checker(self):
        """Check precisely when the logging interval has passed and store data."""
        while self.is_running:
            self.store_data_if_interval_passed()
            time.sleep(0.1)  # Check more frequently for high precision

    def start_fetching(self):
        """Start the background threads for fetching sensor data and logging checker."""
        self.is_running = True
        print("Starting background threads for data fetching and logging.")
        Thread(target=self.fetch_data).start()
        Thread(target=self.start_logging_checker).start()

    def stop_fetching(self):
        """Stop the background threads."""
        self.is_running = False
        print("Stopping background threads.")

# Logging interval class
class LoggingIntervalRequest(BaseModel):
    hours: int
    minutes: int
    seconds: int

# Initialize the sensor data fetcher
port = '/dev/ttyUSB0'
baud = 19200
data_fetcher = SensorDataFetcher(port, baud)
print("SensorDataFetcher initialized.")
