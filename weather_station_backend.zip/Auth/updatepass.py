from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
from passlib.context import CryptContext
import asyncio

# Database configuration
DB_CONFIG = {
    'host': "localhost",
    'port': 3306,
    'user': "root",  # replace with your MariaDB username
    'password': "BeagleBone",  # replace with your MariaDB password
    'db': "weathersensor",  # replace with your database name
}

# Initialize CryptContext for bcrypt
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Create the SQLAlchemy engine
DATABASE_URL = f"mysql+aiomysql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['db']}"
engine = create_async_engine(DATABASE_URL, echo=True)

# Create the session factory
async_session = sessionmaker(
    engine, expire_on_commit=False, class_=AsyncSession
)

# Function to hash the new password
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

# Function to update password in the database
async def update_password(username: str, new_password: str):
    hashed_password = hash_password(new_password)

    async with async_session() as session:
        try:
            query = text("UPDATE userlogin SET password = :password WHERE username = :username")
            await session.execute(query, {"password": hashed_password, "username": username})
            await session.commit()
            print(f"Password for {username} updated successfully!")
        except Exception as e:
            print(f"Error updating password: {e}")
            await session.rollback()

# Main function to execute the password update process
async def main():
    username = input("Enter the username whose password you want to update: ")
    new_password = input("Enter the new password: ")

    await update_password(username, new_password)

if __name__ == "__main__":
    asyncio.run(main())
