from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
from fastapi import HTTPException, Depends
from jose import JWTError, jwt
from passlib.context import CryptContext
import datetime

# Password hashing setup
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Database configuration
DB_CONFIG = {
    'host': "localhost",
    'port': 3306,
    'user': "root",  # replace with your MariaDB username
    'password': "BeagleBone",  # replace with your MariaDB password
    'db': "weathersensor",
}

# JWT configuration
SECRET_KEY = "your_secret_key"  # Replace with a strong secret key
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 5

# Create the SQLAlchemy engine
DATABASE_URL = f"mysql+aiomysql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['db']}"
engine = create_async_engine(DATABASE_URL, echo=True)

# Create the session factory
async_session = sessionmaker(
    engine, expire_on_commit=False, class_=AsyncSession
)

async def get_db_session():
    async with async_session() as session:
        yield session

# Password utilities
def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify if the provided plain password matches the hashed password."""
    return pwd_context.verify(plain_password, hashed_password)

def hash_password(password: str) -> str:
    """Hash a plain password using bcrypt."""
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: datetime.timedelta = None):
    to_encode = data.copy()
    
    # Use timezone-aware datetime (UTC)
    if expires_delta:
        expire = datetime.datetime.now(datetime.timezone.utc) + expires_delta
    else:
        expire = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Verify user credentials
async def verify_user(username: str, password: str):
    """Verify the user against the stored credentials."""
    async with async_session() as session:
        try:
            query = text("SELECT password FROM userlogin WHERE username = :username")
            result = await session.execute(query, {"username": username})
            user_password_hash = result.scalar()

            if user_password_hash:
                # Use `verify_password` to compare the input password with the stored hash
                if verify_password(password, user_password_hash):
                    print(f"Login successful for user: {username}")
                    return {"status": "success"}
                else:
                    print(f"Invalid password for user: {username}")
                    return {"status": "invalid credentials"}
            else:
                print(f"User {username} not found")
                return {"status": "invalid credentials"}

        except Exception as e:
            print(f"Error: {e}")
            return {"status": "error", "message": str(e)}

# Decode and verify a token
def verify_access_token(token: str):
    """Decode and verify a JWT token."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return username
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Migrate plain-text passwords to hashed passwords
async def migrate_passwords():
    """One-time migration script to hash existing plain-text passwords in the database."""
    async with async_session() as session:
        try:
            query = text("SELECT username, password FROM userlogin")
            result = await session.execute(query)
            users = result.fetchall()

            for username, plain_password in users:
                # Hash the plain password and update the database
                hashed_password = hash_password(plain_password)
                update_query = text("UPDATE userlogin SET password = :hashed_password WHERE username = :username")
                await session.execute(update_query, {"hashed_password": hashed_password, "username": username})
                print(f"Password for user {username} hashed and updated.")

            await session.commit()
            print("Password migration completed successfully.")
        except Exception as e:
            print(f"Error during migration: {e}")
            await session.rollback()
