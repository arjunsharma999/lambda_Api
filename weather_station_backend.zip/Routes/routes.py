import datetime
from fastapi import APIRouter, HTTPException, Depends , WebSocket , WebSocketDisconnect , Query
from pydantic import BaseModel
from Models.sensor import data_fetcher
from Models.reports import ReportDate
from datetime import timedelta
from Auth.auth import ACCESS_TOKEN_EXPIRE_MINUTES, get_db_session, verify_access_token
from Auth.auth import  verify_user
from sqlalchemy.ext.asyncio import AsyncSession
from Auth.auth import get_db_session, verify_user, create_access_token
import asyncio
from passlib.context import CryptContext
from Auth.auth import get_db_session
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from fastapi.security import OAuth2PasswordBearer
from Models.ipChange import NetworkConfigurator
from Models.Device_info import DeviceInfo , StorageInfo
from fastapi.responses import JSONResponse 
from Models.gps import start_gps_reader,send_gps_data_via_websocket
from typing import Optional 
from Models.sensor import SensorDataFetcher

sensor_router = APIRouter()

storage_info = StorageInfo()

start_gps_reader()

device_info = DeviceInfo()


#----------------------device id ---------------------------
@sensor_router.get("/api/device_id",response_class=JSONResponse)
async def get_device_id():
    device_id = device_info.get_device_id()
    return{"device_id":device_id}
    
    
#-----------route to send the storgae info ---------
# WebSocket route for real-time storage updates
@sensor_router.websocket("/ws/storage")
async def websocket_storage_status(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            storage_status = storage_info.get_storage_status()  # Fetch real-time storage info
            await websocket.send_json(storage_status) 
            await asyncio.sleep(5)  
    except WebSocketDisconnect:
        logger.info("WebSocket connection closed.")

@sensor_router.get("/api/storage_status", response_class=JSONResponse)
async def get_storage_status():
    storage_status = storage_info.get_storage_status()
    return {"storage_status": storage_status}
    
    
#----------------------gps_routes ---------------------------
@sensor_router.websocket("/ws/gps")
async def websocket_routes(websocket: WebSocket):
    await websocket.accept()
    logger.info("WebSocket connection accepted for /ws/gps")
    try:
        await send_gps_data_via_websocket(websocket)  # Send GPS data via WebSocket
    except WebSocketDisconnect:
        logger.info("WebSocket disconnected for /ws/gps")    
        

#Realtime graph data
@sensor_router.websocket("/ws/sensor/data")  
async def websocket_endpoint(websocket: WebSocket):  
   await websocket.accept()  
   previous_data_hash = None  
   try:  
      while True:  
        if data_fetcher.last_data:  
           current_data_hash = hash(data_fetcher.last_data)  
           if current_data_hash != previous_data_hash:  
              parsed_data = data_fetcher.parse_sensor_data(data_fetcher.last_data)  
              # Send the latest data as JSON  
              await websocket.send_json({  
                "temperature": parsed_data["temperature"],  
                "relative_humidity": parsed_data["relative_humidity"],  
                "wind_speed": parsed_data["wind_speed"],  
                "wind_direction": parsed_data["wind_direction"],  
                "baro_press": parsed_data["baro_press"],  
                "rain": parsed_data["rain"],  
                "battery_voltage": parsed_data["battery_voltage"]  
              })  
              previous_data_hash = current_data_hash  
        await asyncio.sleep(1)  
   except WebSocketDisconnect:  
      print("WebsocketDisconnected")  
   except Exception as e:  
      print(f"unexpected error: {e}")  
   finally:  
      if not websocket.client_state == "DISCONNECTED":  
        await websocket.close()

# Route to fetch available sensor parameters
@sensor_router.get("/sensor/parameters")
async def get_sensor_parameters():
    data_fetcher.fetch_parameters()
    return {"parameters": data_fetcher.parameters}

class LoggingIntervalRequest(BaseModel):
    hours: int
    minutes: int
    seconds: int

# Route to update logging interval
@sensor_router.post("/update-logging-interval/")
def update_logging_interval(logging_interval: LoggingIntervalRequest):
    try:
        # Calculate the total seconds from the request
        new_interval = timedelta(hours=logging_interval.hours, minutes=logging_interval.minutes, seconds=logging_interval.seconds).total_seconds()

        if new_interval < 1:
            raise HTTPException(status_code=400, detail="Logging interval must be at least 1 second")

        # Update the logging interval in the sensor data fetcher
        data_fetcher.logging_interval = new_interval

        return {"message": f"Logging interval updated to {new_interval} seconds"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))  
    
# Route to login
class LoginRequest(BaseModel):
    username: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str

@sensor_router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest, session: AsyncSession = Depends(get_db_session)):
    user = await verify_user(request.username, request.password)
    if user["status"] == "success":
        # Create JWT token
        access_token = create_access_token(
            data={"sub": request.username},
            expires_delta=datetime.timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        )
        return {"access_token": access_token, "token_type": "bearer"}
    else:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )
    
#Proctcted Routes

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/login")

@sensor_router.get("/protected")
async def protected_route(token: str = Depends(oauth2_scheme)):
    username = verify_access_token(token)
    return {"message": f"Hello {username}, you have access to this protected route!"}    


# UpdatePassword
    
class UpdatePasswordRequest(BaseModel):
    username: str
    new_password: str
    
# Initialize CryptContext for bcrypt
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Function to update password
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

@sensor_router.put("/update-password", status_code=status.HTTP_200_OK)
async def update_password(
    payload: UpdatePasswordRequest,
    db: AsyncSession = Depends(get_db_session)
):
    """
    Update a user's password in the database.

    Args:
        payload (UpdatePasswordRequest): The payload containing username and new password.
        db (AsyncSession): The database session dependency.
    """
    username = payload.username
    new_password = payload.new_password

    hashed_password = hash_password(new_password)
    try:
        query = text("UPDATE userlogin SET password = :password WHERE username = :username")
        result = await db.execute(query, {"password": hashed_password, "username": username})

        # Check if the username exists in the database
        if result.rowcount == 0:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User '{username}' not found"
            )
        await db.commit()
        return {"message": "Password updated successfully"}

    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

# Define the threshold model in updateEmail 
class ThresholdUpdateRequest(BaseModel):
    parameter: str                                     
    min: float
    max: float

class UpdateEmailRequest(BaseModel):
    recipient_email: str

class UpdateWhatsAppRequest(BaseModel):
    recipient_phone:str   

class SendEmailRequest(BaseModel):  
   subject: str  
   message: str  
   recipient_email: Optional[str]    

class SendWhatsAppRequest(BaseModel):  
   message: str  
   recipient_phone: Optional[str]   
    

# Create a route to update the email address
@sensor_router.post("/update-email")
def update_email(request: UpdateEmailRequest):
    try:
        # Update the recipient email dynamically
        data_fetcher.recipient_email = request.recipient_email
        return {"message": "Recipient email updated successfully", "new_email": data_fetcher.recipient_email}
    except Exception as e:
        return {"error": str(e)}

@sensor_router.post("/update-whatsapp")  
def update_whatsapp(request: UpdateWhatsAppRequest):  
   try:  
      # Update the recipient WhatsApp phone number dynamically  
      data_fetcher.recipient_phone = request.recipient_phone  
      return {"message": "Recipient WhatsApp phone number updated successfully", "new_phone": data_fetcher.recipient_phone}  
   except Exception as e:  
      return {"error": str(e)}        
         
# Endpoint to fetch current thresholds
@sensor_router.get("/parameters")  
def get_parameters():  
   parameters = list(data_fetcher.thresholds.keys())  
   return {"parameters": parameters}

# Endpoint to update thresholds  
@sensor_router.put("/thresholds")  
def update_threshold(update: ThresholdUpdateRequest):  
   if update.parameter not in data_fetcher.thresholds:  
      raise HTTPException(status_code=404, detail="Parameter not found")  
  
   # Validate input  
   if update.min == "" or update.max == "":  
      raise HTTPException(status_code=400, detail="Both min and max values are required")  
   if update.min > update.max:  
      raise HTTPException(status_code=400, detail="Min value cannot be greater than max value")  
  
   # Update the threshold  
   data_fetcher.thresholds[update.parameter] = {"min": update.min, "max": update.max}  
   return {"message": "Threshold updated successfully"}  
  
@sensor_router.post("/send-email")  
def send_email(request: SendEmailRequest):  
   try:  
      # Use the recipient email from the request if provided, otherwise use the stored recipient email  
      recipient_email = request.recipient_email if request.recipient_email else data_fetcher.recipient_email  
  
      # Send the email  
      Thread(target=data_fetcher.send_email_in_thread, args=(request.subject, request.message, recipient_email)).start()  
      return {"message": "Email sent successfully"}  
   except Exception as e:  
      return {"error": str(e)}

   # Endpoint to send a WhatsApp message  
@sensor_router.post("/send-whatsapp")  
def send_whatsapp(request: SendWhatsAppRequest):  
   try:  
      # Use the recipient phone number from the request if provided, otherwise use the stored recipient phone number  
      recipient_phone = request.recipient_phone if request.recipient_phone else data_fetcher.recipient_phone  
  
      # Send the WhatsApp message  
      data = {  
        'device_id': 'AS756',  
        'date_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),  
        'temperature': data_fetcher.max_temperature,  
        'relative_humidity': data_fetcher.max_rh,  
        'wind_speed': data_fetcher.max_wind_speed,  
        'wind_direction': data_fetcher.max_wind_direction,  
        'baro_press': data_fetcher.max_baro_press,  
        'rain': data_fetcher.max_rain,  
        'battery_voltage': data_fetcher.max_battery_voltage  
      }  
      Thread(target=data_fetcher.send_whatsapp_message, args=(data, recipient_phone)).start()  
      return {"message": "WhatsApp message sent successfully"}  
   except Exception as e:  
      return {"error": str(e)}
          
# Shutdown event to close connections
@sensor_router.on_event("shutdown")
def shutdown_event():
    data_fetcher.stop_fetching()
